Salut <?php echo e($name); ?>,
ceci est un test d'envoi d'emails par laravel avec Gmail? 😉
ismo
<?php /**PATH D:\projetsLaravel\201\24 - mailing\stock\resources\views/mail/test-email.blade.php ENDPATH**/ ?>