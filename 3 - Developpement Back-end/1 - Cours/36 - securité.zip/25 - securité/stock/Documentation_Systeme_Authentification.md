# Documentation du Système d'Authentification

## Introduction

Ce document détaille le système d'authentification implémenté dans le projet Laravel de gestion de stock. Le système comprend les fonctionnalités suivantes :

- Inscription avec vérification par email
- Connexion avec option "se souvenir de moi"
- Réinitialisation de mot de passe
- Gestion de profil utilisateur
- Déconnexion

## Structure de la Base de Données

### Table Users

La table `users` a été modifiée pour prendre en charge la vérification d'email et la gestion des comptes actifs :

- `name` : Nom de l'utilisateur
- `email` : Adresse email (unique)
- `password` : Mot de passe hashé
- `role` : Rôle de l'utilisateur (admin, user, etc.)
- `is_active` : Statut d'activation du compte (boolean)
- `email_verification_token` : Token pour la vérification d'email
- `email_verified_at` : Date de vérification de l'email
- `remember_token` : Token pour la fonctionnalité "se souvenir de moi"

### Table Password Reset Tokens

La table `password_reset_tokens` est utilisée pour stocker les tokens de réinitialisation de mot de passe :

- `email` : Adresse email associée au token
- `token` : Token de réinitialisation
- `created_at` : Date de création du token

## Modèle User

Le modèle `User` a été étendu pour prendre en charge les nouvelles fonctionnalités :

```php
protected $fillable = [
    'name',
    'email',
    'password',
    'role',
    'is_active',
    'email_verification_token',
];

protected $hidden = [
    'password',
    'remember_token',
];

protected function casts(): array
{
    return [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];
}

public function isAdmin(): bool
{
    return $this->role === 'admin';
}
```

## Contrôleur d'Authentification

Le contrôleur `AuthController` gère toutes les fonctionnalités d'authentification :

### Inscription

- Méthode `showRegistrationForm()` : Affiche le formulaire d'inscription
- Méthode `register()` : Traite l'inscription, crée l'utilisateur et envoie un email de vérification

### Vérification d'Email

- Méthode `verificationNotice()` : Affiche la page de notification de vérification
- Méthode `verifyEmail()` : Vérifie le token d'email et active le compte

### Connexion

- Méthode `showLoginForm()` : Affiche le formulaire de connexion
- Méthode `login()` : Traite la connexion avec option "se souvenir de moi"

### Réinitialisation de Mot de Passe

- Méthode `showForgotPasswordForm()` : Affiche le formulaire de demande de réinitialisation
- Méthode `forgotPassword()` : Traite la demande et envoie un email avec le lien de réinitialisation
- Méthode `showResetPasswordForm()` : Affiche le formulaire de réinitialisation
- Méthode `resetPassword()` : Traite la réinitialisation du mot de passe

### Gestion de Profil

- Méthode `showProfile()` : Affiche le profil utilisateur
- Méthode `updateProfile()` : Met à jour les informations du profil
- Méthode `updatePassword()` : Met à jour le mot de passe

### Déconnexion

- Méthode `logout()` : Déconnecte l'utilisateur et invalide la session

## Classes Mail

Deux classes de mail ont été créées pour gérer les notifications par email :

### EmailVerification

Envoie un email de vérification avec un lien contenant le token de vérification :

```php
public function content(): Content
{
    return new Content(
        view: 'mail.email-verification',
        with: [
            'user' => $this->user,
            'verificationUrl' => route('verification.verify', ['token' => $this->user->email_verification_token]),
        ],
    );
}
```

### ResetPassword

Envoie un email de réinitialisation de mot de passe avec un lien contenant le token :

```php
public function content(): Content
{
    return new Content(
        view: 'mail.reset-password',
        with: [
            'token' => $this->token,
            'email' => $this->email,
            'resetUrl' => route('password.reset', ['token' => $this->token, 'email' => $this->email]),
        ],
    );
}
```

## Vues

Les vues suivantes ont été créées pour le système d'authentification :

### Inscription

- `auth.register.blade.php` : Formulaire d'inscription avec validation

### Vérification d'Email

- `auth.verify.blade.php` : Page de notification de vérification d'email
- `mail.email-verification.blade.php` : Template de l'email de vérification

### Connexion

- `auth.login.blade.php` : Formulaire de connexion avec option "se souvenir de moi"

### Réinitialisation de Mot de Passe

- `auth.forgot-password.blade.php` : Formulaire de demande de réinitialisation
- `auth.reset-password.blade.php` : Formulaire de réinitialisation
- `mail.reset-password.blade.php` : Template de l'email de réinitialisation

### Gestion de Profil

- `auth.profile.blade.php` : Page de profil utilisateur

## Flux d'Authentification

### Processus d'Inscription

1. L'utilisateur remplit le formulaire d'inscription
2. Le système crée un compte avec `is_active = false` et génère un token de vérification
3. Un email de vérification est envoyé à l'utilisateur
4. L'utilisateur clique sur le lien dans l'email
5. Le système vérifie le token, active le compte et redirige vers la page de connexion

### Processus de Connexion

1. L'utilisateur remplit le formulaire de connexion
2. Le système vérifie les identifiants et l'état d'activation du compte
3. Si l'option "se souvenir de moi" est cochée, un cookie de session longue durée est créé
4. L'utilisateur est redirigé vers le tableau de bord

### Processus de Réinitialisation de Mot de Passe

1. L'utilisateur demande une réinitialisation de mot de passe
2. Le système génère un token et envoie un email avec un lien de réinitialisation
3. L'utilisateur clique sur le lien et remplit le formulaire de réinitialisation
4. Le système vérifie le token et met à jour le mot de passe

## Sécurité

- Tous les mots de passe sont hashés avec Bcrypt
- Les tokens de vérification et de réinitialisation sont générés de manière aléatoire
- Les sessions sont régénérées lors de la connexion et de la déconnexion
- Les formulaires sont protégés contre les attaques CSRF
- Les validations sont effectuées côté serveur

## Conclusion

Le système d'authentification implémenté offre une solution complète et sécurisée pour la gestion des utilisateurs. Il comprend toutes les fonctionnalités essentielles d'un système d'authentification moderne, avec une attention particulière à la sécurité et à l'expérience utilisateur.