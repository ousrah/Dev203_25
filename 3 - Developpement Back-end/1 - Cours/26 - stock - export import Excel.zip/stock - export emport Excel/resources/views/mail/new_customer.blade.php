salut {{ $name }}
vous venez de vous enregistrer dans notre application de gestion de stock.
Bienvenu dans notre espace.
