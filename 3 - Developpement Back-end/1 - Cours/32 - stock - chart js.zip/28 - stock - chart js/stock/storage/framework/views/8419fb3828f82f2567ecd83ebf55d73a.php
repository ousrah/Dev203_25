salut <?php echo e($name); ?>

vous venez de vous enregistrer dans notre application de gestion de stock.
Bienvenu dans notre espace.
<?php /**PATH D:\projetsLaravel\202\stock - axios\resources\views/mail/new_customer.blade.php ENDPATH**/ ?>