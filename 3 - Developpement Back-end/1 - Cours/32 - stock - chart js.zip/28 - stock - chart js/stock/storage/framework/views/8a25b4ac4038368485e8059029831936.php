<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <style>
        body {
            font-family: sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .product-image {
            max-width: 50px;
            /* Adjust size as needed */
            max-height: 50px;
            display: block;
            /* Helps with alignment if needed */
            margin: auto;
            /* Center image if desired */
        }

        .user-avatar {
            position: absolute;
            top: 10px;
            right: 10px;
            max-width: 60px;
            /* Adjust size as needed */
            max-height: 60px;
            border-radius: 50%;
            /* Optional: make it circular */
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <?php if(isset($user) && $user->avatar): ?>
    <img src="<?php echo e(('storage/avatars/' . $user->avatar)); ?>" alt="User Avatar" class="user-avatar">
    <?php endif; ?>
    <h1>Product List</h1>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Description</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Supplier</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->category->name); ?></td>
                <td><?php echo e($product->description); ?></td>
                <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                <td><?php echo e($product->stock->quantity_stock ?? 0); ?></td>
                <td><?php echo e($product->supplier->first_name); ?> <?php echo e($product->supplier->last_name); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html><?php /**PATH D:\projetsLaravel\201\27 - stock - print mpdf\stock\resources\views/products/print_pdf.blade.php ENDPATH**/ ?>