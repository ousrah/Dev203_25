<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row mb-4">
        <div class="col d-flex justify-content-between align-items-center">
            <h2 class="h3 mb-0">Products by Supplier</h2>
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary d-flex align-items-center gap-2">
                <svg class="bi" width="16" height="16" fill="currentColor">
                    <path fill-rule="evenodd"
                        d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z" />
                </svg>
                Back to Dashboard
            </a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-4">
                    <select class="form-select" id="supplier-select" >
                        <option value="">Select a supplier</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->id); ?>">
                            <?php echo e($supplier->first_name); ?> <?php echo e($supplier->last_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div id="loading" class="text-center d-none">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
            <div id="products-container">
                <!-- Products will be loaded here via Axios -->
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.getElementById('supplier-select').addEventListener('change', function() {
        const supplierId = this.value;

        const loadingElement = document.getElementById('loading');
        const productsContainer = document.getElementById('products-container');
    productsContainer.innerHTML = '';
       if (supplierId) {
            loadingElement.classList.remove('d-none');

            axios.get(`/api/products-by-supplier/${supplierId}`)
                .then(response => {
                    productsContainer.innerHTML = response.data;
                })
                .catch(error => {
                    console.error('Error:', error);
                })
                .finally(() => {
                    loadingElement.classList.add('d-none');
                });
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\202\stock - dashboard\resources\views/products/by-supplier.blade.php ENDPATH**/ ?>