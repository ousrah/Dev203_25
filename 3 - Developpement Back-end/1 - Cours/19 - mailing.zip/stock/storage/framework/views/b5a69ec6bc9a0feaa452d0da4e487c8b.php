Salut <?php echo e($name); ?>,
ceci est un test d'envoi d'emails par laravel avec Gmail? 😉
ismo
<?php /**PATH D:\projetsLaravel\202\stock\resources\views/mail/test-email.blade.php ENDPATH**/ ?>