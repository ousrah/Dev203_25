<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\OrderController;
use App\Mail\MyTestMail;
use Illuminate\Support\Facades\Mail;


Route::get('/', function()
{
    return view('welcome');
});



Route::get('/testmail', function() {
    $name = "ismo developpers";

    // The email sending is done using the to method on the Mail facade
    Mail::to('ousrah@hotmail.com')->send(new MyTestMail($name));
    return 'mail envoyé avec success';
});



