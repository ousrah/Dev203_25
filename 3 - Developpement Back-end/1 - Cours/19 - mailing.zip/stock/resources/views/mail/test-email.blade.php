Salut {{$name}},
ceci est un test d'envoi d'emails par laravel avec Gmail? 😉
ismo
