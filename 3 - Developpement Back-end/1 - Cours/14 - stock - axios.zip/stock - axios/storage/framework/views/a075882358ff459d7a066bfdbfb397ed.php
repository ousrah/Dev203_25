<?php if($products->count() > 0): ?>
<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Description</th>
                <th>Price</th>
                <th>Stock</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->category->name); ?></td>
                <td><?php echo e($product->description); ?></td>
                <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                <td><?php echo e($product->stock ? $product->stock->quantity_stock : 0); ?></td>
            </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>


<?php else: ?>
there is no product for this supplier
<?php endif; ?><?php /**PATH D:\projetsLaravel\202\stock - dashboard\resources\views/products/_products_by_supplier.blade.php ENDPATH**/ ?>