import './bootstrap';
import 'bootstrap';
import '../css/app.css';

// Import all of Bootstrap's JS
import * as bootstrap from 'bootstrap';

// Make it available globally
window.bootstrap = bootstrap;