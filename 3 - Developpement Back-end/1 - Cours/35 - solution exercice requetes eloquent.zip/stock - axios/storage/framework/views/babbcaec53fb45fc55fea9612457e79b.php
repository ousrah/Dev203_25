<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>4 – le nombre des produits par depot.</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Store Id</th>
                <th>Store name</th>
                <th>Count of products</th>

            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($store->store_id); ?></td>
                    <td><?php echo e($store->store_name); ?></td>
                    <td><?php echo e($store->nbProducts); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">Aucun enregistrement trouvé.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary mt-3">Retour au Dashboard</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\201\16 - stock axios orders - cruds cutoers - modals products\stock - axios\resources\views/stores/countbystore.blade.php ENDPATH**/ ?>