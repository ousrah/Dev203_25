<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>2 – afficher la listes des founisseurs qui ont livré les produits commandé par ‘Annabel Stehr’</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Product name</th>
                <th>Supplier name</th>

            </tr>
        </thead>
        <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($supplier->name); ?></td>
                    <td><?php echo e($supplier->first_name); ?> <?php echo e($supplier->last_name); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">Aucun enregistrement trouvé.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary mt-3">Retour au Dashboard</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\201\16 - stock axios orders - cruds cutoers - modals products\stock - axios\resources\views/stores/suppliers_products.blade.php ENDPATH**/ ?>