<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>6 – les depots qui ont une valeur surpérieur a la valeur du depot ‘Lind-Gislason’ <?php echo e($value); ?></h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>store id</th>
                <th>store name</th>
                <th>value</th>

            </tr>
        </thead>
        <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($store->store_id); ?></td>
                    <td><?php echo e($store->store_name); ?></td>
                    <td><?php echo e($store->totalV); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">Aucun enregistrement trouvé.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary mt-3">Retour au Dashboard</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\201\16 - stock axios orders - cruds cutoers - modals products\stock - axios\resources\views/stores/storeGreater_than_lind.blade.php ENDPATH**/ ?>