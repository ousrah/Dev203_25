<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Liste des produits commandés (Juillet 2024)</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nom du produit</th>
                <th>Nom du client</th>
                <th>Catégorie</th>
                <th>Fournisseur</th>
                <th>Date de commande</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($order->product_name); ?></td>
                    <td><?php echo e($order->customer_name); ?></td>
                    <td><?php echo e($order->category_name); ?></td>
                    <td><?php echo e($order->supplier_name); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d/m/Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">Aucune commande trouvée pour juillet 2024.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\201\16 - stock axios orders - cruds cutoers - modals products\stock - axios\resources\views/products/ordered_products.blade.php ENDPATH**/ ?>