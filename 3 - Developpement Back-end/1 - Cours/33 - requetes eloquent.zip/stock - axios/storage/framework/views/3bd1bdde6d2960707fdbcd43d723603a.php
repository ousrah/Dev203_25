<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Clients ayant commandé les mêmes produits que Annabel Stehr</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nom du client</th>
                <th>Email</th>
                <th>Produit commandé</th>
                <th>Date de commande</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($customer->customer_name); ?></td>
                    <td><?php echo e($customer->email); ?></td>
                    <td><?php echo e($customer->product_name); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($customer->order_date)->format('d/m/Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">Aucun autre client n'a commandé les mêmes produits.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary mt-3">Retour au Dashboard</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\201\16 - stock axios orders - cruds cutoers - modals products\stock - axios\resources\views/customers/same_products_customers.blade.php ENDPATH**/ ?>