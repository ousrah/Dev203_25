function my()
{
    alert("my");
}
