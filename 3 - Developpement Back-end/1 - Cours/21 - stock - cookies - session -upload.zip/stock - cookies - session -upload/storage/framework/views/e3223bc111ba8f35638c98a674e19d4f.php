<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Customer Orders</h2>

    <div class="row mb-4">
        <div class="col-md-6">
            <form id="customer-search-form" class="d-flex gap-2">
                <div class="form-group flex-grow-1">
                    <label for="customer-search">Search Customer:</label>
                    <input type="text" id="customer-search" class="form-control"
                        placeholder="Type customer's last name..." required>
                </div>
                <div class="align-self-end">
                    <button type="submit" id="searchCustumers" class="btn btn-primary">Search</button>
                </div>
            </form>
        </div>
        <div class="col-md-6" id="lstCustomers">

        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.getElementById('customer-search-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const searchTerm = document.getElementById('customer-search').value;
    const lstCustomers = document.getElementById('lstCustomers');

    // Show loading state
    lstCustomers.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>';

    axios.get(`/api/customers/search/${searchTerm}`)
        .then(response => {
            if (response.data.length === 0) {
                lstCustomers.innerHTML = '<div class="alert alert-info">No customers found</div>';
                return;
            }

            let html = '<div class="list-group">';
            response.data.forEach(customer => {
                html += `
                    <a href="/orders/${customer.id}" class="list-group-item list-group-item-action">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="mb-1">${customer.first_name} ${customer.last_name}</h6>
                            <small>${customer.email}</small>
                        </div>
                        <small class="text-muted">${customer.phone}</small>
                    </a>`;
            });
            html += '</div>';
            lstCustomers.innerHTML = html;
        })
        .catch(error => {
            lstCustomers.innerHTML = '<div class="alert alert-danger">Error searching for customers</div>';
            console.error('Error:', error);
        });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projetsLaravel\202\stock\resources\views/orders/index.blade.php ENDPATH**/ ?>